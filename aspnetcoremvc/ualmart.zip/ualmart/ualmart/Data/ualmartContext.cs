﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ualmart.Models
{
    public class ualmartContext : DbContext
    {
        public ualmartContext (DbContextOptions<ualmartContext> options)
            : base(options)
        {
        }

        public DbSet<ualmart.Models.Departament> Departament { get; set; }
        public DbSet<ualmart.Models.Seller> Seller { get; set; }
        public DbSet<ualmart.Models.SalesRecord> SalesRecord { get; set; }
    }
}
