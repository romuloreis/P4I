﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ualmart.Services;

namespace ualmart.Controllers
{
    public class SellersController : Controller
    {
        //Injeção de dependência
        private readonly SellerService _sellerService;

        //Construtor para finalizar a injeção de dependência
        public SellersController(SellerService sellerService)
        {
            _sellerService = sellerService;
        }

        public IActionResult Index()
        {
            //Acessa o serviço e chama o método que retorna 
            //a lista de sellers
            var list = _sellerService.FindAll();
            return View(list);
        }
    }
}