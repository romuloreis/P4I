﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ualmart.Models
{
    public class Seller
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime BirthDate { get; set; }
        public double BaseSalary { get; set; }
        public Departament Departament { get; set; }
        ICollection<SalesRecord> Sales { get; set; } =
            new List<SalesRecord>();

        public Seller() { }

        public Seller(int id, string name, string email, DateTime birthDate, double baseSalary, Departament departament)
        {
            Id = id;
            Name = name;
            Email = email;
            BirthDate = birthDate;
            BaseSalary = baseSalary;
            Departament = departament;
        }

        public Seller(string name, string email, DateTime birthDate, double baseSalary, Departament departament)
        {
            Name = name;
            Email = email;
            BirthDate = birthDate;
            BaseSalary = baseSalary;
            Departament = departament;
        }




        /*Adiciona venda na lista de vendas deste vendedor*/
        public void AddSales(SalesRecord sr) {
            Sales.Add(sr);
        }

        public void RemoveSales(SalesRecord sr){
            Sales.Remove(sr);
        }

        public double TotalSales(DateTime initial, DateTime final) {
            /*Vamos utilizar o LINQ para Filtrar a lista de
             vendas com lambda*/
             return Sales.Where(sr => sr.Date >= initial && sr.Date <= final).Sum(sr => sr.Amount);
            /*MinhaLista.Where(ItemDaLista => ItemDaLista.id)*/
        }

    }
}
