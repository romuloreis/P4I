﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ualmart.Models;

namespace ualmart.Services
{
    //Essa é a classe responável por acessar a base de dados
    public class SellerService
    {
        private readonly ualmartContext _context;

        public SellerService(ualmartContext context) {
            _context = context;
        }

        public List<Seller> FindAll() {
            /*Selecionar os objetos da tabela Seller e 
             tansformar em uma lista.
             Por enquanto esse método está sincrono, 
             ou seja, quando essa operação for executada a 
             aplicação vai ficar "parada/aguardando" um retorno.*/
            return _context.Seller.ToList();
        }

    }
}
