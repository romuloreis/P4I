﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SuperBlogRelacional.Migrations
{
    public partial class Corrections : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CommentId",
                table: "Post");

            migrationBuilder.DropColumn(
                name: "PostId",
                table: "Author");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CommentId",
                table: "Post",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "PostId",
                table: "Author",
                nullable: false,
                defaultValue: 0);
        }
    }
}
