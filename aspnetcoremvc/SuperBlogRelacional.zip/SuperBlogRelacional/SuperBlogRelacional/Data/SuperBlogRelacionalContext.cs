﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SuperBlogRelacional.Models;

namespace SuperBlogRelacional.Models
{
    public class SuperBlogRelacionalContext : DbContext
    {
        public SuperBlogRelacionalContext (DbContextOptions<SuperBlogRelacionalContext> options)
            : base(options)
        {
        }

        public DbSet<SuperBlogRelacional.Models.Author> Author { get; set; }

        protected override void OnModelCreating(
            ModelBuilder modelBuilder) {
            //Mesma linha
            modelBuilder.Entity<PostTopic>()
                .HasKey(t => new { t.PostId, t.TopicId });
        }

        public DbSet<SuperBlogRelacional.Models.Comment> Comment { get; set; }

        public DbSet<SuperBlogRelacional.Models.Post> Post { get; set; }

        public DbSet<SuperBlogRelacional.Models.Topic> Topic { get; set; }

        public DbSet<SuperBlogRelacional.Models.PostTopic> PostTopic { get; set; }
    }
}
