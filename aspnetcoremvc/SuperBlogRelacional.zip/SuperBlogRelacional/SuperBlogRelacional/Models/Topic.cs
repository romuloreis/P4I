﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SuperBlogRelacional.Models
{
    public class Topic
    {
        public int TopicId { get; set; }

        [Required]
        [MaxLength(15, ErrorMessage="Muito Longo"), MinLength(3, ErrorMessage = "Muito Curto")]
        public string Name { get; set; }

        public ICollection<PostTopic> PostTopics { get; set; }
    }
}
