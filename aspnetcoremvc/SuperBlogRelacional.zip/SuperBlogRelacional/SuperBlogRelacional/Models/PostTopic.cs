﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SuperBlogRelacional.Models
{
    public class PostTopic
    {
        public int PostId { get; set; }
        public Post Post { get; set; }

        public int TopicId { get; set; }
        public Topic Topic { get; set; }
    }
}
