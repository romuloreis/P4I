﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SuperBlogRelacional.Models
{
    public class Post
    {
        public int PostId { get; set; }

        [Required]
        [MaxLength(15, ErrorMessage = "Muito Longo"), MinLength(3, ErrorMessage = "Muito Curto")]
        public string Title { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        [Required]
        [MaxLength(200, ErrorMessage = "Muito Longo"), MinLength(5, ErrorMessage = "Muito Curto")]
        public string Content { get; set; }

        /*Todo post é escrito por um autor*/
        public int AuthorId { get; set; }
        public Author Author { get; set; }

        /*Todo post pode conter vários comentários*/
        public ICollection<Comment> Comments { get; set; }

        public ICollection<PostTopic> PostTopics { get; set; }
    }
}
