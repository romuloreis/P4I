﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SuperBlogRelacional.Models
{
    public class Author
    {
        public int AuthorId { get; set; }

        [Required]
        [MaxLength(30, ErrorMessage = "Muito Longo"), MinLength(3, ErrorMessage = "Muito Curto")]
        public string Name { get; set; }

        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [DataType(DataType.PhoneNumber)]        
        public string Phone { get; set; }

        /*Cria a relação com a classe Post*/
        public ICollection<Post> Posts { get; set; }
    }
}
