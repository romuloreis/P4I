﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SuperBlogRelacional.Models
{
    public class Comment
    {
        public int CommentId { get; set; }
        public string Content { get; set; }

        [Range(300, 3000)]
        public int Grade { get; set; }

        /*Todo comentário pertence à uma postagem*/
        public int PostId { get; set; }
        public Post Post { get; set; }
    }
}
