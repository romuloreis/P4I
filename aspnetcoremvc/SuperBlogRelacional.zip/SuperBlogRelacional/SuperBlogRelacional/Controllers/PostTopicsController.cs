﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SuperBlogRelacional.Models;

namespace SuperBlogRelacional.Controllers
{
    public class PostTopicsController : Controller
    {
        private readonly SuperBlogRelacionalContext _context;

        public PostTopicsController(SuperBlogRelacionalContext context)
        {
            _context = context;
        }

        // GET: PostTopics
        public async Task<IActionResult> Index()
        {
            var superBlogRelacionalContext = _context.PostTopic.Include(p => p.Post).Include(p => p.Topic);
            return View(await superBlogRelacionalContext.ToListAsync());
        }

        // GET: PostTopics/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var postTopic = await _context.PostTopic
                .Include(p => p.Post)
                .Include(p => p.Topic)
                .FirstOrDefaultAsync(m => m.PostId == id);
            if (postTopic == null)
            {
                return NotFound();
            }

            return View(postTopic);
        }

        // GET: PostTopics/Create
        public IActionResult Create()
        {
            ViewData["PostId"] = new SelectList(_context.Post, "PostId", "Content");
            ViewData["TopicId"] = new SelectList(_context.Topic, "TopicId", "Name");
            return View();
        }

        // POST: PostTopics/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PostId,TopicId")] PostTopic postTopic)
        {
            if (ModelState.IsValid)
            {
                _context.Add(postTopic);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PostId"] = new SelectList(_context.Post, "PostId", "Content", postTopic.PostId);
            ViewData["TopicId"] = new SelectList(_context.Topic, "TopicId", "Name", postTopic.TopicId);
            return View(postTopic);
        }

        // GET: PostTopics/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var postTopic = await _context.PostTopic.FindAsync(id);
            if (postTopic == null)
            {
                return NotFound();
            }
            ViewData["PostId"] = new SelectList(_context.Post, "PostId", "Content", postTopic.PostId);
            ViewData["TopicId"] = new SelectList(_context.Topic, "TopicId", "Name", postTopic.TopicId);
            return View(postTopic);
        }

        // POST: PostTopics/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PostId,TopicId")] PostTopic postTopic)
        {
            if (id != postTopic.PostId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(postTopic);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PostTopicExists(postTopic.PostId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PostId"] = new SelectList(_context.Post, "PostId", "Content", postTopic.PostId);
            ViewData["TopicId"] = new SelectList(_context.Topic, "TopicId", "Name", postTopic.TopicId);
            return View(postTopic);
        }

        // GET: PostTopics/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var postTopic = await _context.PostTopic
                .Include(p => p.Post)
                .Include(p => p.Topic)
                .FirstOrDefaultAsync(m => m.PostId == id);
            if (postTopic == null)
            {
                return NotFound();
            }

            return View(postTopic);
        }

        // POST: PostTopics/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var postTopic = await _context.PostTopic.FindAsync(id);
            _context.PostTopic.Remove(postTopic);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PostTopicExists(int id)
        {
            return _context.PostTopic.Any(e => e.PostId == id);
        }
    }
}
