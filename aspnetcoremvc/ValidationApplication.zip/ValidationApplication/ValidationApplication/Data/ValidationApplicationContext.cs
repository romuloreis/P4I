﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ValidationApplication.Models;

namespace ValidationApplication.Models
{
    public class ValidationApplicationContext : DbContext
    {
        public ValidationApplicationContext (DbContextOptions<ValidationApplicationContext> options)
            : base(options)
        {
        }

        public DbSet<ValidationApplication.Models.Company> Company { get; set; }

        public DbSet<ValidationApplication.Models.Department> Department { get; set; }

        public DbSet<ValidationApplication.Models.Employee> Employee { get; set; }
    }
}
