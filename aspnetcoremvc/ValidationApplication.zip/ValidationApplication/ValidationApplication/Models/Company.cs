﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ValidationApplication.Models
{
    public class Company
    {
        /*[Key]Essa notação deixa explicito 
        que essa propriedade é a chave primária*/
        public int CompanyId { get; set; }

        /*Required torna obrigatório o preenchimento 
         do campo*/
        [Required]
        [Display(Name = "Company Name")]
        /*Define o tamanho máximo, mensagem de erro e 
         tamanho minímo para o campo name*/
        [StringLength(15, 
            ErrorMessage ="Must be between 5 and 10", 
            MinimumLength =5)]
        public string Name { get; set; }

        [Required(ErrorMessage="CNPJ is required!!!!")]
        //MinLength(14), MaxLength(14)
        //[StringLength(14)]
        public int Cnpj { get; set; }

        public string Address { get; set; }

        public ICollection<Department> Departments { get; set;}
    }
}
