﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ValidationApplication.Models
{
    public class Department
    {
        public int DepartmentId { get; set; }

        [Required, MinLength(5), MaxLength(20)]
        public string Name { get; set; }

        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        //Funaciona para cel
        [DataType(DataType.PhoneNumber)]
        public string Phone { get; set; }

        public int CompanyId { get; set; }
        public Company Company { get; set; }

        public ICollection<Employee> Employees { get; set; }

    }
}
