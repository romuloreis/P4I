﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ValidationApplication.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        [Display(Name ="Employee Name")]
        public string Name { get; set; }

        [Display(Name="Phone Number")]
        [Phone]
        public string Phone { get; set; }

        [Required(ErrorMessage ="Please, enter your e-mail")]
        [Display(Name = "Contact E-mail")]
        [DataType(DataType.EmailAddress)]
        //[RegularExpression(@"^\w+([-+.']\w+)@\w+([-.]\w+).\w+([-.]\w+)*$", ErrorMessage = "Email is not valid.")]
        public string Email { get; set; }

        [DisplayFormat(DataFormatString ="0:00000.00")]
        [Range(1000, 15000, ErrorMessage ="Insert a valid number")]
        public decimal Salary { get; set; }

        [DisplayFormat(DataFormatString = "0:dd.MM.yyyy")]
        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        public int DepartmentId { get; set; }
        public Department Department { get; set; }

        /*Essas duas propriedades de relação 
         * são opcionais nesse caso*/
        //public int CompanyId { get; set; }
        //public Company Company { get; set; }

    }
}
